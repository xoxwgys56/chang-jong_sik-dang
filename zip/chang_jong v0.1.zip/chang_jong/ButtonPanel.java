package chang_jong;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

public class ButtonPanel extends JPanel {

	public ButtonPanel() {
		Dimension res = Toolkit.getDefaultToolkit().getScreenSize();
		int wid=(res.width);				//��ư �г� ����
		int hei=((res.height/10));			//��ư �г� ����
		setBorder(new LineBorder(new Color(0, 0, 0)));
		setLayout(null);
		setSize(wid, hei);
		
		
		JButton TableButton = new JButton("���̺�����");
		TableButton.setBounds(0, 0, wid/15, hei);
		add(TableButton);

	}
	
}
