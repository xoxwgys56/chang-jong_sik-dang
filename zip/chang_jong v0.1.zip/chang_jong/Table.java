package chang_jong;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Table {

	private boolean cursor_entered = false;
	private boolean cursor_pressed = false;
	private boolean cursor_dragged = false;
	
	private int x, y;
	private int cursor_x, cursor_y;
	private static final int width = 60, height = 60;
	private BufferedImage table_img, out_table_img;
	
	public Table(int x, int y) {
		this.x = x;
		this.y = y;
		
		try {
			table_img = ImageIO.read(new File("res/table.png"));
			out_table_img = ImageIO.read(new File("res/out_table.png"));
			
		} catch(IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
	}
	
	public void render(Graphics g) {
		
		if (cursor_entered && cursor_pressed) {
			g.drawImage(out_table_img, cursor_x-width/2, cursor_y-height/2, width, height, null);
			
			x = cursor_x-width/2;
			y = cursor_y-height/2;
			
			//System.out.println("cursor_x : " + cursor_x);
			
			return ;
		}
		
		if (cursor_entered)
			g.drawImage(out_table_img, x, y, width, height, null);
		else	
			g.drawImage(table_img, x, y, width, height, null);
		
	}
	
	
	public boolean check_table(int cursor_x, int cursor_y, boolean cursor_pressed, boolean cursor_dragged) {
		
		this.cursor_pressed = cursor_pressed;
		this.cursor_dragged = cursor_dragged;
		this.cursor_x = cursor_x;
		this.cursor_y = cursor_y;
		
		if (cursor_x >= x && cursor_x <= x+width 
				&& cursor_y >= y && cursor_y <= y+height){
			cursor_entered = true;
			
			return true;
		} else {
			cursor_entered = false;
			
			return false;
		}
	}
	
}
