package chang_jong;

public class Launcher {
	//main
		public static void main(String[] args) {
			FrameWork main = new FrameWork();
			main.start();
		}
}
