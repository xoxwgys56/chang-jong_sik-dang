package test;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetDragEvent;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.dnd.DropTargetEvent;
import java.awt.dnd.DropTargetListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class DnDText extends JFrame implements DropTargetListener{
    JTextArea editor;
    DropTarget target;
   
    public DnDText(){
        super("Drag & Drop");
        editor = new JTextArea();
        target = new DropTarget(editor,DnDConstants.ACTION_COPY_OR_MOVE,
                (DropTargetListener) this,true,null);
        getContentPane().add("Center",new JScrollPane(editor));
       
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(450,500);
        setVisible(true);
    }
    /* DropTargetListener �������̽� ������ ���� �κ� */
    public void dragEnter(DropTargetDragEvent dtde){
        System.out.println("dragEnter");
    }
    public void dragExit(DropTargetEvent dtde){
        System.out.println("dragExit");
    }
    public void dragOver(DropTargetDragEvent dtde){
        System.out.println("dragOver");
    }
    public void drop(DropTargetDropEvent dtde){
        System.out.println("drop");
        //�׼��� copy or move�� ��쿡 �о���δ�.
        if((dtde.getDropAction() &
                DnDConstants.ACTION_COPY_OR_MOVE)!=0){
            dtde.acceptDrop(dtde.getDropAction());
            Transferable tr = dtde.getTransferable();
            try{
                //���޵Ǵ� ������ ����Ʈ���·� ��ȯ
                //���ϸ���Ʈ�� DataFlavor�� �̿��Ͽ� tr�� ����
                java.util.List list = (java.util.List)
                tr.getTransferData(DataFlavor.javaFileListFlavor);
                //����Ʈ�� ù��° ���Ҹ� ���Ϸ� �о���δ�.
                File file = (File)list.get(0);
                char buf[] = new char[1024];
                BufferedReader in = new BufferedReader(new  FileReader(file));
                int n = -1;
                editor.setText("");
                while((n=in.read(buf,0,1024))!=-1){
                    editor.append(new String(buf,0,n));
                }
                in.close();
            }catch(Exception e){
                e.printStackTrace();
            }
        }
    }
    public void dropActionChanged(DropTargetDragEvent dtde){
        System.out.println("dropActionChanged");
    }
    public static void main(String[] args) {
        new DnDText();
    }
   
   
}
